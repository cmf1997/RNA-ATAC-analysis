#' color values
#'
#' @export
color_values <- c(
                  "Opening" = "#B2182B",
                  "opening" = "#B2182B",
                  "up" = "#B2182B",
                  "Up" = "#B2182B",

                  "Closing" = "#2166ACFF",
                  "closing" = "#2166ACFF",
                  "Down" = "#2166ACFF",
                  "down" = "#2166ACFF"
)
